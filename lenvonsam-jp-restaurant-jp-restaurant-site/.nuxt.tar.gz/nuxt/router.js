import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _23e6ccf5 = () => interopDefault(import('../pages/bk/index.vue' /* webpackChunkName: "pages/bk/index" */))
const _3c7e9f41 = () => interopDefault(import('../pages/mb/index.vue' /* webpackChunkName: "pages/mb/index" */))
const _2f0f7bc2 = () => interopDefault(import('../pages/pc/index.vue' /* webpackChunkName: "pages/pc/index" */))
const _3f68afb2 = () => interopDefault(import('../pages/bk/appoint/index.vue' /* webpackChunkName: "pages/bk/appoint/index" */))
const _6ca0d25c = () => interopDefault(import('../pages/bk/banner/index.vue' /* webpackChunkName: "pages/bk/banner/index" */))
const _24e31fe8 = () => interopDefault(import('../pages/bk/login.vue' /* webpackChunkName: "pages/bk/login" */))
const _2c15ce90 = () => interopDefault(import('../pages/bk/merchant/index.vue' /* webpackChunkName: "pages/bk/merchant/index" */))
const _c1ad0afa = () => interopDefault(import('../pages/bk/news/index.vue' /* webpackChunkName: "pages/bk/news/index" */))
const _288284d5 = () => interopDefault(import('../pages/bk/product/index.vue' /* webpackChunkName: "pages/bk/product/index" */))
const _8ffbf50a = () => interopDefault(import('../pages/bk/user/index.vue' /* webpackChunkName: "pages/bk/user/index" */))
const _cd7b231a = () => interopDefault(import('../pages/mb/appoint/index.vue' /* webpackChunkName: "pages/mb/appoint/index" */))
const _118f13c4 = () => interopDefault(import('../pages/mb/intro/index.vue' /* webpackChunkName: "pages/mb/intro/index" */))
const _285537b7 = () => interopDefault(import('../pages/mb/news/index.vue' /* webpackChunkName: "pages/mb/news/index" */))
const _1dd25351 = () => interopDefault(import('../pages/pc/appoint/index.vue' /* webpackChunkName: "pages/pc/appoint/index" */))
const _d4d00b08 = () => interopDefault(import('../pages/pc/intro/index.vue' /* webpackChunkName: "pages/pc/intro/index" */))
const _0836a0ce = () => interopDefault(import('../pages/pc/news/index.vue' /* webpackChunkName: "pages/pc/news/index" */))
const _6ee88f86 = () => interopDefault(import('../pages/bk/appoint/constant.ts' /* webpackChunkName: "pages/bk/appoint/constant" */))
const _3a9c007b = () => interopDefault(import('../pages/bk/banner/constant.ts' /* webpackChunkName: "pages/bk/banner/constant" */))
const _f72ba4cc = () => interopDefault(import('../pages/bk/merchant/card.vue' /* webpackChunkName: "pages/bk/merchant/card" */))
const _980fc052 = () => interopDefault(import('../pages/bk/merchant/constant.ts' /* webpackChunkName: "pages/bk/merchant/constant" */))
const _24c98a3c = () => interopDefault(import('../pages/bk/news/constant.ts' /* webpackChunkName: "pages/bk/news/constant" */))
const _f64a0e98 = () => interopDefault(import('../pages/bk/product/constant.ts' /* webpackChunkName: "pages/bk/product/constant" */))
const _292124ac = () => interopDefault(import('../pages/bk/product/menu.vue' /* webpackChunkName: "pages/bk/product/menu" */))
const _327ce7da = () => interopDefault(import('../pages/bk/user/constant.ts' /* webpackChunkName: "pages/bk/user/constant" */))
const _435f7127 = () => interopDefault(import('../pages/mb/merchant/detail.vue' /* webpackChunkName: "pages/mb/merchant/detail" */))
const _7aa4cebc = () => interopDefault(import('../pages/mb/news/detail.vue' /* webpackChunkName: "pages/mb/news/detail" */))
const _38ecd2f6 = () => interopDefault(import('../pages/pc/merchant/detail.vue' /* webpackChunkName: "pages/pc/merchant/detail" */))
const _1904531a = () => interopDefault(import('../pages/pc/news/detail.vue' /* webpackChunkName: "pages/pc/news/detail" */))
const _bd0b498e = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/bk",
    component: _23e6ccf5,
    name: "bk"
  }, {
    path: "/mb",
    component: _3c7e9f41,
    name: "mb"
  }, {
    path: "/pc",
    component: _2f0f7bc2,
    name: "pc"
  }, {
    path: "/bk/appoint",
    component: _3f68afb2,
    name: "bk-appoint"
  }, {
    path: "/bk/banner",
    component: _6ca0d25c,
    name: "bk-banner"
  }, {
    path: "/bk/login",
    component: _24e31fe8,
    name: "bk-login"
  }, {
    path: "/bk/merchant",
    component: _2c15ce90,
    name: "bk-merchant"
  }, {
    path: "/bk/news",
    component: _c1ad0afa,
    name: "bk-news"
  }, {
    path: "/bk/product",
    component: _288284d5,
    name: "bk-product"
  }, {
    path: "/bk/user",
    component: _8ffbf50a,
    name: "bk-user"
  }, {
    path: "/mb/appoint",
    component: _cd7b231a,
    name: "mb-appoint"
  }, {
    path: "/mb/intro",
    component: _118f13c4,
    name: "mb-intro"
  }, {
    path: "/mb/news",
    component: _285537b7,
    name: "mb-news"
  }, {
    path: "/pc/appoint",
    component: _1dd25351,
    name: "pc-appoint"
  }, {
    path: "/pc/intro",
    component: _d4d00b08,
    name: "pc-intro"
  }, {
    path: "/pc/news",
    component: _0836a0ce,
    name: "pc-news"
  }, {
    path: "/bk/appoint/constant",
    component: _6ee88f86,
    name: "bk-appoint-constant"
  }, {
    path: "/bk/banner/constant",
    component: _3a9c007b,
    name: "bk-banner-constant"
  }, {
    path: "/bk/merchant/card",
    component: _f72ba4cc,
    name: "bk-merchant-card"
  }, {
    path: "/bk/merchant/constant",
    component: _980fc052,
    name: "bk-merchant-constant"
  }, {
    path: "/bk/news/constant",
    component: _24c98a3c,
    name: "bk-news-constant"
  }, {
    path: "/bk/product/constant",
    component: _f64a0e98,
    name: "bk-product-constant"
  }, {
    path: "/bk/product/menu",
    component: _292124ac,
    name: "bk-product-menu"
  }, {
    path: "/bk/user/constant",
    component: _327ce7da,
    name: "bk-user-constant"
  }, {
    path: "/mb/merchant/detail",
    component: _435f7127,
    name: "mb-merchant-detail"
  }, {
    path: "/mb/news/detail",
    component: _7aa4cebc,
    name: "mb-news-detail"
  }, {
    path: "/pc/merchant/detail",
    component: _38ecd2f6,
    name: "pc-merchant-detail"
  }, {
    path: "/pc/news/detail",
    component: _1904531a,
    name: "pc-news-detail"
  }, {
    path: "/",
    component: _bd0b498e,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
